/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/jllpz/Desktop/Arqui/Practica2_SumResAnt/SumRes.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1605435078_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_2507238156_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_2545490612_503743352(char *, unsigned char , unsigned char );


static void work_a_3861480626_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    int t9;
    char *t10;
    int t11;
    int t12;
    char *t13;
    char *t14;
    char *t15;
    int t16;
    int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    unsigned char t22;
    unsigned char t23;
    char *t24;
    char *t25;
    int t26;
    int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    char *t32;
    int t33;
    int t34;
    int t35;
    unsigned char t36;
    int t37;
    int t38;
    int t39;
    unsigned char t40;
    int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned char t45;
    unsigned char t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;

LAB0:    xsi_set_current_line(22, ng0);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 1968U);
    t4 = *((char **)t1);
    t5 = (0 - 4);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t1 = (t4 + t8);
    *((unsigned char *)t1) = t3;
    xsi_set_current_line(23, ng0);
    t1 = (t0 + 6376);
    *((int *)t1) = 0;
    t2 = (t0 + 6380);
    *((int *)t2) = 3;
    t5 = 0;
    t9 = 3;

LAB2:    if (t5 <= t9)
        goto LAB3;

LAB5:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 1968U);
    t2 = *((char **)t1);
    t5 = (4 - 4);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t1 = (t2 + t8);
    t3 = *((unsigned char *)t1);
    t4 = (t0 + 4016);
    t10 = (t4 + 56U);
    t13 = *((char **)t10);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = t3;
    xsi_driver_first_trans_fast_port(t4);
    t1 = (t0 + 3872);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(24, ng0);
    t4 = (t0 + 1032U);
    t10 = *((char **)t4);
    t4 = (t0 + 6376);
    t11 = *((int *)t4);
    t12 = (t11 - 3);
    t6 = (t12 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t4));
    t7 = (1U * t6);
    t8 = (0 + t7);
    t13 = (t10 + t8);
    t3 = *((unsigned char *)t13);
    t14 = (t0 + 1192U);
    t15 = *((char **)t14);
    t14 = (t0 + 6376);
    t16 = *((int *)t14);
    t17 = (t16 - 3);
    t18 = (t17 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t14));
    t19 = (1U * t18);
    t20 = (0 + t19);
    t21 = (t15 + t20);
    t22 = *((unsigned char *)t21);
    t23 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t3, t22);
    t24 = (t0 + 2088U);
    t25 = *((char **)t24);
    t24 = (t0 + 6376);
    t26 = *((int *)t24);
    t27 = (t26 - 3);
    t28 = (t27 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t24));
    t29 = (1U * t28);
    t30 = (0 + t29);
    t31 = (t25 + t30);
    *((unsigned char *)t31) = t23;
    xsi_set_current_line(25, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6376);
    t11 = *((int *)t1);
    t12 = (t11 - 3);
    t6 = (t12 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t1));
    t7 = (1U * t6);
    t8 = (0 + t7);
    t4 = (t2 + t8);
    t3 = *((unsigned char *)t4);
    t10 = (t0 + 1192U);
    t13 = *((char **)t10);
    t10 = (t0 + 6376);
    t16 = *((int *)t10);
    t17 = (t16 - 3);
    t18 = (t17 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t10));
    t19 = (1U * t18);
    t20 = (0 + t19);
    t14 = (t13 + t20);
    t22 = *((unsigned char *)t14);
    t23 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t3, t22);
    t15 = (t0 + 2208U);
    t21 = *((char **)t15);
    t15 = (t0 + 6376);
    t26 = *((int *)t15);
    t27 = (t26 - 3);
    t28 = (t27 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t15));
    t29 = (1U * t28);
    t30 = (0 + t29);
    t24 = (t21 + t30);
    *((unsigned char *)t24) = t23;
    xsi_set_current_line(26, ng0);
    t1 = (t0 + 2208U);
    t2 = *((char **)t1);
    t1 = (t0 + 6376);
    t11 = *((int *)t1);
    t12 = (t11 - 3);
    t6 = (t12 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t1));
    t7 = (1U * t6);
    t8 = (0 + t7);
    t4 = (t2 + t8);
    t3 = *((unsigned char *)t4);
    t10 = (t0 + 1968U);
    t13 = *((char **)t10);
    t10 = (t0 + 6376);
    t16 = *((int *)t10);
    t17 = (t16 - 4);
    t18 = (t17 * -1);
    xsi_vhdl_check_range_of_index(4, 0, -1, *((int *)t10));
    t19 = (1U * t18);
    t20 = (0 + t19);
    t14 = (t13 + t20);
    t22 = *((unsigned char *)t14);
    t23 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t3, t22);
    t15 = (t0 + 6376);
    t26 = *((int *)t15);
    t27 = (t26 - 3);
    t28 = (t27 * -1);
    t29 = (1 * t28);
    t30 = (0U + t29);
    t21 = (t0 + 3952);
    t24 = (t21 + 56U);
    t25 = *((char **)t24);
    t31 = (t25 + 56U);
    t32 = *((char **)t31);
    *((unsigned char *)t32) = t23;
    xsi_driver_first_trans_delta(t21, t30, 1, 0LL);
    xsi_set_current_line(28, ng0);
    t1 = (t0 + 6376);
    t2 = (t0 + 6384);
    *((int *)t2) = 0;
    t4 = (t0 + 6388);
    *((int *)t4) = *((int *)t1);
    t11 = 0;
    t12 = *((int *)t1);

LAB6:    if (t11 <= t12)
        goto LAB7;

LAB9:    xsi_set_current_line(36, ng0);
    t1 = (t0 + 6392);
    *((int *)t1) = 0;
    t2 = (t0 + 6396);
    *((int *)t2) = 2;
    t11 = 0;
    t12 = 2;

LAB14:    if (t11 <= t12)
        goto LAB15;

LAB17:    xsi_set_current_line(55, ng0);
    t1 = (t0 + 2088U);
    t2 = *((char **)t1);
    t1 = (t0 + 6376);
    t11 = *((int *)t1);
    t12 = (t11 - 3);
    t6 = (t12 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t1));
    t7 = (1U * t6);
    t8 = (0 + t7);
    t4 = (t2 + t8);
    t3 = *((unsigned char *)t4);
    t10 = (t0 + 1968U);
    t13 = *((char **)t10);
    t16 = (0 - 4);
    t18 = (t16 * -1);
    t19 = (1U * t18);
    t20 = (0 + t19);
    t10 = (t13 + t20);
    t22 = *((unsigned char *)t10);
    t14 = (t0 + 2328U);
    t15 = *((char **)t14);
    t17 = (3 - 3);
    t28 = (t17 * -1);
    t29 = (1U * t28);
    t30 = (0 + t29);
    t14 = (t15 + t30);
    t23 = *((unsigned char *)t14);
    t36 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t22, t23);
    t40 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t3, t36);
    t21 = (t0 + 2568U);
    t24 = *((char **)t21);
    t26 = (2 - 2);
    t42 = (t26 * -1);
    t43 = (1U * t42);
    t44 = (0 + t43);
    t21 = (t24 + t44);
    t45 = *((unsigned char *)t21);
    t46 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t40, t45);
    t25 = (t0 + 1968U);
    t31 = *((char **)t25);
    t25 = (t0 + 6376);
    t27 = *((int *)t25);
    t33 = (t27 + 1);
    t34 = (t33 - 4);
    t47 = (t34 * -1);
    xsi_vhdl_check_range_of_index(4, 0, -1, t33);
    t48 = (1U * t47);
    t49 = (0 + t48);
    t32 = (t31 + t49);
    *((unsigned char *)t32) = t46;

LAB4:    t1 = (t0 + 6376);
    t5 = *((int *)t1);
    t2 = (t0 + 6380);
    t9 = *((int *)t2);
    if (t5 == t9)
        goto LAB5;

LAB32:    t11 = (t5 + 1);
    t5 = t11;
    t4 = (t0 + 6376);
    *((int *)t4) = t5;
    goto LAB2;

LAB7:    xsi_set_current_line(29, ng0);
    t10 = (t0 + 6384);
    t16 = *((int *)t10);
    t3 = (t16 == 0);
    if (t3 != 0)
        goto LAB10;

LAB12:    xsi_set_current_line(32, ng0);
    t1 = (t0 + 2328U);
    t2 = *((char **)t1);
    t1 = (t0 + 6384);
    t16 = *((int *)t1);
    t17 = (t16 - 1);
    t26 = (t17 - 3);
    t6 = (t26 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, t17);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t4 = (t2 + t8);
    t3 = *((unsigned char *)t4);
    t10 = (t0 + 2208U);
    t13 = *((char **)t10);
    t10 = (t0 + 6384);
    t27 = *((int *)t10);
    t33 = (t27 - 3);
    t18 = (t33 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t10));
    t19 = (1U * t18);
    t20 = (0 + t19);
    t14 = (t13 + t20);
    t22 = *((unsigned char *)t14);
    t23 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t3, t22);
    t15 = (t0 + 2328U);
    t21 = *((char **)t15);
    t15 = (t0 + 6384);
    t34 = *((int *)t15);
    t35 = (t34 - 3);
    t28 = (t35 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t15));
    t29 = (1U * t28);
    t30 = (0 + t29);
    t24 = (t21 + t30);
    *((unsigned char *)t24) = t23;

LAB11:
LAB8:    t1 = (t0 + 6384);
    t11 = *((int *)t1);
    t2 = (t0 + 6388);
    t12 = *((int *)t2);
    if (t11 == t12)
        goto LAB9;

LAB13:    t16 = (t11 + 1);
    t11 = t16;
    t4 = (t0 + 6384);
    *((int *)t4) = t11;
    goto LAB6;

LAB10:    xsi_set_current_line(30, ng0);
    t13 = (t0 + 2208U);
    t14 = *((char **)t13);
    t13 = (t0 + 6384);
    t17 = *((int *)t13);
    t26 = (t17 - 3);
    t6 = (t26 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t13));
    t7 = (1U * t6);
    t8 = (0 + t7);
    t15 = (t14 + t8);
    t22 = *((unsigned char *)t15);
    t21 = (t0 + 2328U);
    t24 = *((char **)t21);
    t21 = (t0 + 6384);
    t27 = *((int *)t21);
    t33 = (t27 - 3);
    t18 = (t33 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t21));
    t19 = (1U * t18);
    t20 = (0 + t19);
    t25 = (t24 + t20);
    *((unsigned char *)t25) = t22;
    goto LAB11;

LAB15:    xsi_set_current_line(38, ng0);
    t4 = (t0 + 6400);
    *((int *)t4) = 1;
    t10 = (t0 + 6404);
    *((int *)t10) = 3;
    t16 = 1;
    t17 = 3;

LAB18:    if (t16 <= t17)
        goto LAB19;

LAB21:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 6392);
    t16 = *((int *)t1);
    t3 = (t16 == 0);
    if (t3 != 0)
        goto LAB28;

LAB30:    xsi_set_current_line(51, ng0);
    t1 = (t0 + 2568U);
    t2 = *((char **)t1);
    t1 = (t0 + 6392);
    t16 = *((int *)t1);
    t17 = (t16 - 1);
    t26 = (t17 - 2);
    t6 = (t26 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, t17);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t4 = (t2 + t8);
    t3 = *((unsigned char *)t4);
    t10 = (t0 + 2088U);
    t13 = *((char **)t10);
    t10 = (t0 + 6392);
    t27 = *((int *)t10);
    t33 = (t27 - 3);
    t18 = (t33 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t10));
    t19 = (1U * t18);
    t20 = (0 + t19);
    t14 = (t13 + t20);
    t22 = *((unsigned char *)t14);
    t15 = (t0 + 2448U);
    t21 = *((char **)t15);
    t15 = (t0 + 6392);
    t34 = *((int *)t15);
    t35 = (t34 + 1);
    t37 = (3 - t35);
    t38 = (t37 - 2);
    t28 = (t38 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, t37);
    t29 = (1U * t28);
    t30 = (0 + t29);
    t24 = (t21 + t30);
    t23 = *((unsigned char *)t24);
    t36 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t22, t23);
    t40 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t3, t36);
    t25 = (t0 + 2568U);
    t31 = *((char **)t25);
    t25 = (t0 + 6392);
    t39 = *((int *)t25);
    t41 = (t39 - 2);
    t42 = (t41 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, *((int *)t25));
    t43 = (1U * t42);
    t44 = (0 + t43);
    t32 = (t31 + t44);
    *((unsigned char *)t32) = t40;

LAB29:
LAB16:    t1 = (t0 + 6392);
    t11 = *((int *)t1);
    t2 = (t0 + 6396);
    t12 = *((int *)t2);
    if (t11 == t12)
        goto LAB17;

LAB31:    t16 = (t11 + 1);
    t11 = t16;
    t4 = (t0 + 6392);
    *((int *)t4) = t11;
    goto LAB14;

LAB19:    xsi_set_current_line(39, ng0);
    t13 = (t0 + 6400);
    t26 = *((int *)t13);
    t3 = (t26 == 1);
    if (t3 != 0)
        goto LAB22;

LAB24:    t1 = (t0 + 6400);
    t26 = *((int *)t1);
    t3 = (t26 == 2);
    if (t3 != 0)
        goto LAB25;

LAB26:    xsi_set_current_line(44, ng0);
    t1 = (t0 + 2448U);
    t2 = *((char **)t1);
    t1 = (t0 + 6400);
    t26 = *((int *)t1);
    t27 = (t26 - 2);
    t33 = (t27 - 2);
    t6 = (t33 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, t27);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t4 = (t2 + t8);
    t3 = *((unsigned char *)t4);
    t10 = (t0 + 2208U);
    t13 = *((char **)t10);
    t34 = (1 - 3);
    t18 = (t34 * -1);
    t19 = (1U * t18);
    t20 = (0 + t19);
    t10 = (t13 + t20);
    t22 = *((unsigned char *)t10);
    t23 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t3, t22);
    t14 = (t0 + 2448U);
    t15 = *((char **)t14);
    t14 = (t0 + 6400);
    t35 = *((int *)t14);
    t37 = (t35 - 1);
    t38 = (t37 - 2);
    t28 = (t38 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, t37);
    t29 = (1U * t28);
    t30 = (0 + t29);
    t21 = (t15 + t30);
    *((unsigned char *)t21) = t23;

LAB23:
LAB20:    t1 = (t0 + 6400);
    t16 = *((int *)t1);
    t2 = (t0 + 6404);
    t17 = *((int *)t2);
    if (t16 == t17)
        goto LAB21;

LAB27:    t26 = (t16 + 1);
    t16 = t26;
    t4 = (t0 + 6400);
    *((int *)t4) = t16;
    goto LAB18;

LAB22:    xsi_set_current_line(40, ng0);
    t14 = (t0 + 2208U);
    t15 = *((char **)t14);
    t27 = (3 - 3);
    t6 = (t27 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t14 = (t15 + t8);
    t22 = *((unsigned char *)t14);
    t21 = (t0 + 2448U);
    t24 = *((char **)t21);
    t21 = (t0 + 6400);
    t33 = *((int *)t21);
    t34 = (t33 - 1);
    t35 = (t34 - 2);
    t18 = (t35 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, t34);
    t19 = (1U * t18);
    t20 = (0 + t19);
    t25 = (t24 + t20);
    *((unsigned char *)t25) = t22;
    goto LAB23;

LAB25:    xsi_set_current_line(42, ng0);
    t2 = (t0 + 2448U);
    t4 = *((char **)t2);
    t2 = (t0 + 6400);
    t27 = *((int *)t2);
    t33 = (t27 - 2);
    t34 = (t33 - 2);
    t6 = (t34 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, t33);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t10 = (t4 + t8);
    t22 = *((unsigned char *)t10);
    t13 = (t0 + 2208U);
    t14 = *((char **)t13);
    t35 = (2 - 3);
    t18 = (t35 * -1);
    t19 = (1U * t18);
    t20 = (0 + t19);
    t13 = (t14 + t20);
    t23 = *((unsigned char *)t13);
    t36 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t22, t23);
    t15 = (t0 + 2448U);
    t21 = *((char **)t15);
    t15 = (t0 + 6400);
    t37 = *((int *)t15);
    t38 = (t37 - 1);
    t39 = (t38 - 2);
    t28 = (t39 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, t38);
    t29 = (1U * t28);
    t30 = (0 + t29);
    t24 = (t21 + t30);
    *((unsigned char *)t24) = t36;
    goto LAB23;

LAB28:    xsi_set_current_line(49, ng0);
    t2 = (t0 + 2088U);
    t4 = *((char **)t2);
    t2 = (t0 + 6392);
    t17 = *((int *)t2);
    t26 = (t17 - 3);
    t6 = (t26 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t2));
    t7 = (1U * t6);
    t8 = (0 + t7);
    t10 = (t4 + t8);
    t22 = *((unsigned char *)t10);
    t13 = (t0 + 2448U);
    t14 = *((char **)t13);
    t27 = (2 - 2);
    t18 = (t27 * -1);
    t19 = (1U * t18);
    t20 = (0 + t19);
    t13 = (t14 + t20);
    t23 = *((unsigned char *)t13);
    t36 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t22, t23);
    t15 = (t0 + 2568U);
    t21 = *((char **)t15);
    t15 = (t0 + 6392);
    t33 = *((int *)t15);
    t34 = (t33 - 2);
    t28 = (t34 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, *((int *)t15));
    t29 = (1U * t28);
    t30 = (0 + t29);
    t24 = (t21 + t30);
    *((unsigned char *)t24) = t36;
    goto LAB29;

}


extern void work_a_3861480626_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3861480626_3212880686_p_0};
	xsi_register_didat("work_a_3861480626_3212880686", "isim/testBench_isim_beh.exe.sim/work/a_3861480626_3212880686.didat");
	xsi_register_executes(pe);
}
