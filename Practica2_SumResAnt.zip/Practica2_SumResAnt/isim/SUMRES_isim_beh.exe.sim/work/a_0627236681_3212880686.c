/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Cristhian653/Desktop/20170918/Practica2/SumResAnticipado/SumRes.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1605435078_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_2507238156_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_2545490612_503743352(char *, unsigned char , unsigned char );


static void work_a_0627236681_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    int t9;
    int t10;
    char *t11;
    int t12;
    int t13;
    char *t14;
    char *t15;
    char *t16;
    int t17;
    int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    unsigned char t23;
    unsigned char t24;
    char *t25;
    char *t26;
    int t27;
    int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;
    char *t33;
    int t34;
    int t35;
    int t36;
    int t37;
    unsigned char t38;
    int t39;
    unsigned char t40;
    int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned char t45;
    unsigned char t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;

LAB0:    xsi_set_current_line(28, ng0);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 2088U);
    t4 = *((char **)t1);
    t5 = (0 - 4);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t1 = (t4 + t8);
    *((unsigned char *)t1) = t3;
    xsi_set_current_line(29, ng0);
    t5 = (4 - 1);
    t1 = (t0 + 6848);
    *((int *)t1) = 0;
    t2 = (t0 + 6852);
    *((int *)t2) = t5;
    t9 = 0;
    t10 = t5;

LAB2:    if (t9 <= t10)
        goto LAB3;

LAB5:    xsi_set_current_line(64, ng0);
    t1 = (t0 + 2088U);
    t2 = *((char **)t1);
    t5 = (4 - 4);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t1 = (t2 + t8);
    t3 = *((unsigned char *)t1);
    t4 = (t0 + 4136);
    t11 = (t4 + 56U);
    t14 = *((char **)t11);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = t3;
    xsi_driver_first_trans_fast_port(t4);
    t1 = (t0 + 3992);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(30, ng0);
    t4 = (t0 + 1032U);
    t11 = *((char **)t4);
    t4 = (t0 + 6848);
    t12 = *((int *)t4);
    t13 = (t12 - 3);
    t6 = (t13 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t4));
    t7 = (1U * t6);
    t8 = (0 + t7);
    t14 = (t11 + t8);
    t3 = *((unsigned char *)t14);
    t15 = (t0 + 1192U);
    t16 = *((char **)t15);
    t15 = (t0 + 6848);
    t17 = *((int *)t15);
    t18 = (t17 - 3);
    t19 = (t18 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t15));
    t20 = (1U * t19);
    t21 = (0 + t20);
    t22 = (t16 + t21);
    t23 = *((unsigned char *)t22);
    t24 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t3, t23);
    t25 = (t0 + 2208U);
    t26 = *((char **)t25);
    t25 = (t0 + 6848);
    t27 = *((int *)t25);
    t28 = (t27 - 3);
    t29 = (t28 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t25));
    t30 = (1U * t29);
    t31 = (0 + t30);
    t32 = (t26 + t31);
    *((unsigned char *)t32) = t24;
    xsi_set_current_line(31, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6848);
    t5 = *((int *)t1);
    t12 = (t5 - 3);
    t6 = (t12 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t1));
    t7 = (1U * t6);
    t8 = (0 + t7);
    t4 = (t2 + t8);
    t3 = *((unsigned char *)t4);
    t11 = (t0 + 1192U);
    t14 = *((char **)t11);
    t11 = (t0 + 6848);
    t13 = *((int *)t11);
    t17 = (t13 - 3);
    t19 = (t17 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t11));
    t20 = (1U * t19);
    t21 = (0 + t20);
    t15 = (t14 + t21);
    t23 = *((unsigned char *)t15);
    t24 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t3, t23);
    t16 = (t0 + 2328U);
    t22 = *((char **)t16);
    t16 = (t0 + 6848);
    t18 = *((int *)t16);
    t27 = (t18 - 3);
    t29 = (t27 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t16));
    t30 = (1U * t29);
    t31 = (0 + t30);
    t25 = (t22 + t31);
    *((unsigned char *)t25) = t24;
    xsi_set_current_line(32, ng0);
    t1 = (t0 + 2328U);
    t2 = *((char **)t1);
    t1 = (t0 + 6848);
    t5 = *((int *)t1);
    t12 = (t5 - 3);
    t6 = (t12 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t1));
    t7 = (1U * t6);
    t8 = (0 + t7);
    t4 = (t2 + t8);
    t3 = *((unsigned char *)t4);
    t11 = (t0 + 2088U);
    t14 = *((char **)t11);
    t11 = (t0 + 6848);
    t13 = *((int *)t11);
    t17 = (t13 - 4);
    t19 = (t17 * -1);
    xsi_vhdl_check_range_of_index(4, 0, -1, *((int *)t11));
    t20 = (1U * t19);
    t21 = (0 + t20);
    t15 = (t14 + t21);
    t23 = *((unsigned char *)t15);
    t24 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t3, t23);
    t16 = (t0 + 6848);
    t18 = *((int *)t16);
    t27 = (t18 - 3);
    t29 = (t27 * -1);
    t30 = (1 * t29);
    t31 = (0U + t30);
    t22 = (t0 + 4072);
    t25 = (t22 + 56U);
    t26 = *((char **)t25);
    t32 = (t26 + 56U);
    t33 = *((char **)t32);
    *((unsigned char *)t33) = t24;
    xsi_driver_first_trans_delta(t22, t31, 1, 0LL);
    xsi_set_current_line(33, ng0);
    t1 = (t0 + 6848);
    t2 = (t0 + 6856);
    *((int *)t2) = 0;
    t4 = (t0 + 6860);
    *((int *)t4) = *((int *)t1);
    t5 = 0;
    t12 = *((int *)t1);

LAB6:    if (t5 <= t12)
        goto LAB7;

LAB9:    xsi_set_current_line(41, ng0);
    t5 = (4 - 2);
    t1 = (t0 + 6864);
    *((int *)t1) = 0;
    t2 = (t0 + 6868);
    *((int *)t2) = t5;
    t12 = 0;
    t13 = t5;

LAB14:    if (t12 <= t13)
        goto LAB15;

LAB17:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 2208U);
    t2 = *((char **)t1);
    t1 = (t0 + 6848);
    t5 = *((int *)t1);
    t12 = (t5 - 3);
    t6 = (t12 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t1));
    t7 = (1U * t6);
    t8 = (0 + t7);
    t4 = (t2 + t8);
    t3 = *((unsigned char *)t4);
    t11 = (t0 + 2088U);
    t14 = *((char **)t11);
    t13 = (0 - 4);
    t19 = (t13 * -1);
    t20 = (1U * t19);
    t21 = (0 + t20);
    t11 = (t14 + t21);
    t23 = *((unsigned char *)t11);
    t15 = (t0 + 2448U);
    t16 = *((char **)t15);
    t17 = (3 - 3);
    t29 = (t17 * -1);
    t30 = (1U * t29);
    t31 = (0 + t30);
    t15 = (t16 + t31);
    t24 = *((unsigned char *)t15);
    t38 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t23, t24);
    t40 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t3, t38);
    t22 = (t0 + 2688U);
    t25 = *((char **)t22);
    t18 = (2 - 2);
    t42 = (t18 * -1);
    t43 = (1U * t42);
    t44 = (0 + t43);
    t22 = (t25 + t44);
    t45 = *((unsigned char *)t22);
    t46 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t40, t45);
    t26 = (t0 + 2088U);
    t32 = *((char **)t26);
    t26 = (t0 + 6848);
    t27 = *((int *)t26);
    t28 = (t27 + 1);
    t34 = (t28 - 4);
    t47 = (t34 * -1);
    xsi_vhdl_check_range_of_index(4, 0, -1, t28);
    t48 = (1U * t47);
    t49 = (0 + t48);
    t33 = (t32 + t49);
    *((unsigned char *)t33) = t46;

LAB4:    t1 = (t0 + 6848);
    t9 = *((int *)t1);
    t2 = (t0 + 6852);
    t10 = *((int *)t2);
    if (t9 == t10)
        goto LAB5;

LAB32:    t5 = (t9 + 1);
    t9 = t5;
    t4 = (t0 + 6848);
    *((int *)t4) = t9;
    goto LAB2;

LAB7:    xsi_set_current_line(34, ng0);
    t11 = (t0 + 6856);
    t13 = *((int *)t11);
    t3 = (t13 == 0);
    if (t3 != 0)
        goto LAB10;

LAB12:    xsi_set_current_line(37, ng0);
    t1 = (t0 + 2448U);
    t2 = *((char **)t1);
    t1 = (t0 + 6856);
    t13 = *((int *)t1);
    t17 = (t13 - 1);
    t18 = (t17 - 3);
    t6 = (t18 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, t17);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t4 = (t2 + t8);
    t3 = *((unsigned char *)t4);
    t11 = (t0 + 2328U);
    t14 = *((char **)t11);
    t11 = (t0 + 6856);
    t27 = *((int *)t11);
    t28 = (t27 - 3);
    t19 = (t28 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t11));
    t20 = (1U * t19);
    t21 = (0 + t20);
    t15 = (t14 + t21);
    t23 = *((unsigned char *)t15);
    t24 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t3, t23);
    t16 = (t0 + 2448U);
    t22 = *((char **)t16);
    t16 = (t0 + 6856);
    t34 = *((int *)t16);
    t35 = (t34 - 3);
    t29 = (t35 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t16));
    t30 = (1U * t29);
    t31 = (0 + t30);
    t25 = (t22 + t31);
    *((unsigned char *)t25) = t24;

LAB11:
LAB8:    t1 = (t0 + 6856);
    t5 = *((int *)t1);
    t2 = (t0 + 6860);
    t12 = *((int *)t2);
    if (t5 == t12)
        goto LAB9;

LAB13:    t13 = (t5 + 1);
    t5 = t13;
    t4 = (t0 + 6856);
    *((int *)t4) = t5;
    goto LAB6;

LAB10:    xsi_set_current_line(35, ng0);
    t14 = (t0 + 2328U);
    t15 = *((char **)t14);
    t14 = (t0 + 6856);
    t17 = *((int *)t14);
    t18 = (t17 - 3);
    t6 = (t18 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t14));
    t7 = (1U * t6);
    t8 = (0 + t7);
    t16 = (t15 + t8);
    t23 = *((unsigned char *)t16);
    t22 = (t0 + 2448U);
    t25 = *((char **)t22);
    t22 = (t0 + 6856);
    t27 = *((int *)t22);
    t28 = (t27 - 3);
    t19 = (t28 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t22));
    t20 = (1U * t19);
    t21 = (0 + t20);
    t26 = (t25 + t21);
    *((unsigned char *)t26) = t23;
    goto LAB11;

LAB15:    xsi_set_current_line(43, ng0);
    t17 = (4 - 1);
    t4 = (t0 + 6872);
    *((int *)t4) = 1;
    t11 = (t0 + 6876);
    *((int *)t11) = t17;
    t18 = 1;
    t27 = t17;

LAB18:    if (t18 <= t27)
        goto LAB19;

LAB21:    xsi_set_current_line(53, ng0);
    t1 = (t0 + 6864);
    t5 = *((int *)t1);
    t3 = (t5 == 0);
    if (t3 != 0)
        goto LAB28;

LAB30:    xsi_set_current_line(56, ng0);
    t1 = (t0 + 2688U);
    t2 = *((char **)t1);
    t1 = (t0 + 6864);
    t5 = *((int *)t1);
    t17 = (t5 - 1);
    t18 = (t17 - 2);
    t6 = (t18 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, t17);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t4 = (t2 + t8);
    t3 = *((unsigned char *)t4);
    t11 = (t0 + 2208U);
    t14 = *((char **)t11);
    t11 = (t0 + 6864);
    t27 = *((int *)t11);
    t28 = (t27 - 3);
    t19 = (t28 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t11));
    t20 = (1U * t19);
    t21 = (0 + t20);
    t15 = (t14 + t21);
    t23 = *((unsigned char *)t15);
    t16 = (t0 + 2568U);
    t22 = *((char **)t16);
    t16 = (t0 + 6864);
    t34 = *((int *)t16);
    t35 = (t34 + 1);
    t36 = (3 - t35);
    t37 = (t36 - 2);
    t29 = (t37 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, t36);
    t30 = (1U * t29);
    t31 = (0 + t30);
    t25 = (t22 + t31);
    t24 = *((unsigned char *)t25);
    t38 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t23, t24);
    t40 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t3, t38);
    t26 = (t0 + 2688U);
    t32 = *((char **)t26);
    t26 = (t0 + 6864);
    t39 = *((int *)t26);
    t41 = (t39 - 2);
    t42 = (t41 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, *((int *)t26));
    t43 = (1U * t42);
    t44 = (0 + t43);
    t33 = (t32 + t44);
    *((unsigned char *)t33) = t40;

LAB29:
LAB16:    t1 = (t0 + 6864);
    t12 = *((int *)t1);
    t2 = (t0 + 6868);
    t13 = *((int *)t2);
    if (t12 == t13)
        goto LAB17;

LAB31:    t5 = (t12 + 1);
    t12 = t5;
    t4 = (t0 + 6864);
    *((int *)t4) = t12;
    goto LAB14;

LAB19:    xsi_set_current_line(44, ng0);
    t14 = (t0 + 6872);
    t28 = *((int *)t14);
    t3 = (t28 == 1);
    if (t3 != 0)
        goto LAB22;

LAB24:    t1 = (t0 + 6872);
    t5 = *((int *)t1);
    t3 = (t5 == 2);
    if (t3 != 0)
        goto LAB25;

LAB26:    xsi_set_current_line(49, ng0);
    t1 = (t0 + 2568U);
    t2 = *((char **)t1);
    t1 = (t0 + 6872);
    t5 = *((int *)t1);
    t17 = (t5 - 2);
    t28 = (t17 - 2);
    t6 = (t28 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, t17);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t4 = (t2 + t8);
    t3 = *((unsigned char *)t4);
    t11 = (t0 + 2328U);
    t14 = *((char **)t11);
    t34 = (1 - 3);
    t19 = (t34 * -1);
    t20 = (1U * t19);
    t21 = (0 + t20);
    t11 = (t14 + t21);
    t23 = *((unsigned char *)t11);
    t24 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t3, t23);
    t15 = (t0 + 2568U);
    t16 = *((char **)t15);
    t15 = (t0 + 6872);
    t35 = *((int *)t15);
    t36 = (t35 - 1);
    t37 = (t36 - 2);
    t29 = (t37 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, t36);
    t30 = (1U * t29);
    t31 = (0 + t30);
    t22 = (t16 + t31);
    *((unsigned char *)t22) = t24;

LAB23:
LAB20:    t1 = (t0 + 6872);
    t18 = *((int *)t1);
    t2 = (t0 + 6876);
    t27 = *((int *)t2);
    if (t18 == t27)
        goto LAB21;

LAB27:    t5 = (t18 + 1);
    t18 = t5;
    t4 = (t0 + 6872);
    *((int *)t4) = t18;
    goto LAB18;

LAB22:    xsi_set_current_line(45, ng0);
    t15 = (t0 + 2328U);
    t16 = *((char **)t15);
    t34 = (3 - 3);
    t6 = (t34 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t15 = (t16 + t8);
    t23 = *((unsigned char *)t15);
    t22 = (t0 + 2568U);
    t25 = *((char **)t22);
    t22 = (t0 + 6872);
    t35 = *((int *)t22);
    t36 = (t35 - 1);
    t37 = (t36 - 2);
    t19 = (t37 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, t36);
    t20 = (1U * t19);
    t21 = (0 + t20);
    t26 = (t25 + t21);
    *((unsigned char *)t26) = t23;
    goto LAB23;

LAB25:    xsi_set_current_line(47, ng0);
    t2 = (t0 + 2568U);
    t4 = *((char **)t2);
    t2 = (t0 + 6872);
    t17 = *((int *)t2);
    t28 = (t17 - 2);
    t34 = (t28 - 2);
    t6 = (t34 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, t28);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t11 = (t4 + t8);
    t23 = *((unsigned char *)t11);
    t14 = (t0 + 2328U);
    t15 = *((char **)t14);
    t35 = (2 - 3);
    t19 = (t35 * -1);
    t20 = (1U * t19);
    t21 = (0 + t20);
    t14 = (t15 + t21);
    t24 = *((unsigned char *)t14);
    t38 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t23, t24);
    t16 = (t0 + 2568U);
    t22 = *((char **)t16);
    t16 = (t0 + 6872);
    t36 = *((int *)t16);
    t37 = (t36 - 1);
    t39 = (t37 - 2);
    t29 = (t39 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, t37);
    t30 = (1U * t29);
    t31 = (0 + t30);
    t25 = (t22 + t31);
    *((unsigned char *)t25) = t38;
    goto LAB23;

LAB28:    xsi_set_current_line(54, ng0);
    t2 = (t0 + 2208U);
    t4 = *((char **)t2);
    t2 = (t0 + 6864);
    t17 = *((int *)t2);
    t18 = (t17 - 3);
    t6 = (t18 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t2));
    t7 = (1U * t6);
    t8 = (0 + t7);
    t11 = (t4 + t8);
    t23 = *((unsigned char *)t11);
    t14 = (t0 + 2568U);
    t15 = *((char **)t14);
    t27 = (2 - 2);
    t19 = (t27 * -1);
    t20 = (1U * t19);
    t21 = (0 + t20);
    t14 = (t15 + t21);
    t24 = *((unsigned char *)t14);
    t38 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t23, t24);
    t16 = (t0 + 2688U);
    t22 = *((char **)t16);
    t16 = (t0 + 6864);
    t28 = *((int *)t16);
    t34 = (t28 - 2);
    t29 = (t34 * -1);
    xsi_vhdl_check_range_of_index(2, 0, -1, *((int *)t16));
    t30 = (1U * t29);
    t31 = (0 + t30);
    t25 = (t22 + t31);
    *((unsigned char *)t25) = t38;
    goto LAB29;

}


extern void work_a_0627236681_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0627236681_3212880686_p_0};
	xsi_register_didat("work_a_0627236681_3212880686", "isim/SUMRES_isim_beh.exe.sim/work/a_0627236681_3212880686.didat");
	xsi_register_executes(pe);
}
