/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/jllpz/Desktop/Arqui/Practica4_FileReg/FileRegister/fileRegister/barrelShifter.vhd";



static void work_a_1633651022_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int t4;
    int t5;
    int t6;
    char *t7;
    char *t8;
    int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned char t13;
    unsigned char t14;
    char *t15;
    int t16;
    int t17;
    unsigned char t18;
    char *t19;
    int t20;
    int t21;
    char *t22;
    int t23;
    int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;

LAB0:    xsi_set_current_line(25, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 1808U);
    t3 = *((char **)t1);
    t1 = (t3 + 0);
    memcpy(t1, t2, 16U);
    xsi_set_current_line(26, ng0);
    t1 = (t0 + 5588);
    *((int *)t1) = 0;
    t2 = (t0 + 5592);
    *((int *)t2) = 3;
    t4 = 0;
    t5 = 3;

LAB2:    if (t4 <= t5)
        goto LAB3;

LAB5:    xsi_set_current_line(50, ng0);
    t1 = (t0 + 1808U);
    t2 = *((char **)t1);
    t1 = (t0 + 3312);
    t3 = (t1 + 56U);
    t7 = *((char **)t3);
    t8 = (t7 + 56U);
    t15 = *((char **)t8);
    memcpy(t15, t2, 16U);
    xsi_driver_first_trans_fast_port(t1);
    t1 = (t0 + 3232);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(27, ng0);
    t3 = (t0 + 5588);
    t6 = xsi_vhdl_pow(2, *((int *)t3));
    t7 = (t0 + 1928U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = t6;
    xsi_set_current_line(28, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 5588);
    t6 = *((int *)t1);
    t9 = (t6 - 3);
    t10 = (t9 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, *((int *)t1));
    t11 = (1U * t10);
    t12 = (0 + t11);
    t3 = (t2 + t12);
    t13 = *((unsigned char *)t3);
    t14 = (t13 == (unsigned char)2);
    if (t14 != 0)
        goto LAB6;

LAB8:    xsi_set_current_line(31, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t13 = *((unsigned char *)t2);
    t14 = (t13 == (unsigned char)3);
    if (t14 != 0)
        goto LAB9;

LAB11:    xsi_set_current_line(40, ng0);
    t1 = (t0 + 5604);
    *((int *)t1) = 0;
    t2 = (t0 + 5608);
    *((int *)t2) = 15;
    t6 = 0;
    t9 = 15;

LAB20:    if (t6 <= t9)
        goto LAB21;

LAB23:
LAB10:
LAB7:
LAB4:    t1 = (t0 + 5588);
    t4 = *((int *)t1);
    t2 = (t0 + 5592);
    t5 = *((int *)t2);
    if (t4 == t5)
        goto LAB5;

LAB28:    t6 = (t4 + 1);
    t4 = t6;
    t3 = (t0 + 5588);
    *((int *)t3) = t4;
    goto LAB2;

LAB6:    xsi_set_current_line(29, ng0);
    t7 = (t0 + 1808U);
    t8 = *((char **)t7);
    t7 = (t0 + 1808U);
    t15 = *((char **)t7);
    t7 = (t15 + 0);
    memcpy(t7, t8, 16U);
    goto LAB7;

LAB9:    xsi_set_current_line(32, ng0);
    t1 = (t0 + 5596);
    *((int *)t1) = 15;
    t3 = (t0 + 5600);
    *((int *)t3) = 0;
    t6 = 15;
    t9 = 0;

LAB12:    if (t6 >= t9)
        goto LAB13;

LAB15:    goto LAB10;

LAB13:    xsi_set_current_line(33, ng0);
    t7 = (t0 + 5596);
    t8 = (t0 + 1928U);
    t15 = *((char **)t8);
    t16 = *((int *)t15);
    t17 = *((int *)t7);
    t18 = (t17 < t16);
    if (t18 != 0)
        goto LAB16;

LAB18:    xsi_set_current_line(36, ng0);
    t1 = (t0 + 1808U);
    t2 = *((char **)t1);
    t1 = (t0 + 5596);
    t3 = (t0 + 1928U);
    t7 = *((char **)t3);
    t16 = *((int *)t7);
    t17 = *((int *)t1);
    t20 = (t17 - t16);
    t21 = (t20 - 15);
    t10 = (t21 * -1);
    xsi_vhdl_check_range_of_index(15, 0, -1, t20);
    t11 = (1U * t10);
    t12 = (0 + t11);
    t3 = (t2 + t12);
    t13 = *((unsigned char *)t3);
    t8 = (t0 + 1808U);
    t15 = *((char **)t8);
    t8 = (t0 + 5596);
    t23 = *((int *)t8);
    t24 = (t23 - 15);
    t25 = (t24 * -1);
    xsi_vhdl_check_range_of_index(15, 0, -1, *((int *)t8));
    t26 = (1U * t25);
    t27 = (0 + t26);
    t19 = (t15 + t27);
    *((unsigned char *)t19) = t13;

LAB17:
LAB14:    t1 = (t0 + 5596);
    t6 = *((int *)t1);
    t2 = (t0 + 5600);
    t9 = *((int *)t2);
    if (t6 == t9)
        goto LAB15;

LAB19:    t16 = (t6 + -1);
    t6 = t16;
    t3 = (t0 + 5596);
    *((int *)t3) = t6;
    goto LAB12;

LAB16:    xsi_set_current_line(34, ng0);
    t8 = (t0 + 1808U);
    t19 = *((char **)t8);
    t8 = (t0 + 5596);
    t20 = *((int *)t8);
    t21 = (t20 - 15);
    t10 = (t21 * -1);
    xsi_vhdl_check_range_of_index(15, 0, -1, *((int *)t8));
    t11 = (1U * t10);
    t12 = (0 + t11);
    t22 = (t19 + t12);
    *((unsigned char *)t22) = (unsigned char)2;
    goto LAB17;

LAB21:    xsi_set_current_line(41, ng0);
    t3 = (t0 + 5604);
    t7 = (t0 + 1928U);
    t8 = *((char **)t7);
    t16 = *((int *)t8);
    t17 = (15 - t16);
    t20 = *((int *)t3);
    t13 = (t20 > t17);
    if (t13 != 0)
        goto LAB24;

LAB26:    xsi_set_current_line(44, ng0);
    t1 = (t0 + 1808U);
    t2 = *((char **)t1);
    t1 = (t0 + 5604);
    t3 = (t0 + 1928U);
    t7 = *((char **)t3);
    t16 = *((int *)t7);
    t17 = *((int *)t1);
    t20 = (t17 + t16);
    t21 = (t20 - 15);
    t10 = (t21 * -1);
    xsi_vhdl_check_range_of_index(15, 0, -1, t20);
    t11 = (1U * t10);
    t12 = (0 + t11);
    t3 = (t2 + t12);
    t13 = *((unsigned char *)t3);
    t8 = (t0 + 1808U);
    t15 = *((char **)t8);
    t8 = (t0 + 5604);
    t23 = *((int *)t8);
    t24 = (t23 - 15);
    t25 = (t24 * -1);
    xsi_vhdl_check_range_of_index(15, 0, -1, *((int *)t8));
    t26 = (1U * t25);
    t27 = (0 + t26);
    t19 = (t15 + t27);
    *((unsigned char *)t19) = t13;

LAB25:
LAB22:    t1 = (t0 + 5604);
    t6 = *((int *)t1);
    t2 = (t0 + 5608);
    t9 = *((int *)t2);
    if (t6 == t9)
        goto LAB23;

LAB27:    t16 = (t6 + 1);
    t6 = t16;
    t3 = (t0 + 5604);
    *((int *)t3) = t6;
    goto LAB20;

LAB24:    xsi_set_current_line(42, ng0);
    t7 = (t0 + 1808U);
    t15 = *((char **)t7);
    t7 = (t0 + 5604);
    t21 = *((int *)t7);
    t23 = (t21 - 15);
    t10 = (t23 * -1);
    xsi_vhdl_check_range_of_index(15, 0, -1, *((int *)t7));
    t11 = (1U * t10);
    t12 = (0 + t11);
    t19 = (t15 + t12);
    *((unsigned char *)t19) = (unsigned char)2;
    goto LAB25;

}


extern void work_a_1633651022_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1633651022_3212880686_p_0};
	xsi_register_didat("work_a_1633651022_3212880686", "isim/simulations_isim_beh.exe.sim/work/a_1633651022_3212880686.didat");
	xsi_register_executes(pe);
}
